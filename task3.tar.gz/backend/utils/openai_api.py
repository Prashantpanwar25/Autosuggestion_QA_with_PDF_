import openai
import logging
import asyncio
import json
import os
from typing import List, Dict, Any

class OpenAI:
    def __init__(self, api_key: str):
        """Initialize OpenAI API client
        
        Args:
            api_key: OpenAI API key
        """
        self.api_key = api_key
        openai.api_key = api_key
        self.logger = logging.getLogger(__name__)

    async def generate_embedding(self, text: str) -> List[float]:
        """Generate embeddings for text
        
        Args:
            text: Input text
            
        Returns:
            List of embedding values
        """
        try:
            # Split text into chunks if too long
            max_tokens = 8192
            if len(text.split()) > max_tokens:
                chunks = self._split_text_into_chunks(text, max_tokens)
                embeddings = []
                for chunk in chunks:
                    response = await self._get_embedding(chunk)
                    embeddings.extend(response)
                return embeddings
            else:
                return await self._get_embedding(text)
                
        except Exception as e:
            self.logger.error(f"Error generating embedding: {str(e)}", exc_info=True)
            raise

    async def _get_embedding(self, text: str) -> List[float]:
        """Get embedding for a single chunk of text
        
        Args:
            text: Input text
            
        Returns:
            List of embedding values
        """
        try:
            response = await openai.Embedding.acreate(
                input=text,
                model="text-embedding-ada-002"
            )
            return response.data[0].embedding
            
        except Exception as e:
            self.logger.error(f"Error getting embedding: {str(e)}", exc_info=True)
            raise

    async def generate_answer(self, prompt: str) -> str:
        """Generate answer to question
        
        Args:
            prompt: Input prompt
            
        Returns:
            Generated answer
        """
        try:
            response = await openai.ChatCompletion.acreate(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=1500
            )
            return response.choices[0].message.content
            
        except Exception as e:
            self.logger.error(f"Error generating answer: {str(e)}", exc_info=True)
            raise

    async def generate_suggestions(self, prompt: str) -> List[str]:
        """Generate question suggestions
        
        Args:
            prompt: Input prompt
            
        Returns:
            List of suggested questions
        """
        try:
            response = await openai.ChatCompletion.acreate(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=500
            )
            suggestions = response.choices[0].message.content.split("\n")
            return [s.strip() for s in suggestions if s.strip()]
            
        except Exception as e:
            self.logger.error(f"Error generating suggestions: {str(e)}", exc_info=True)
            raise

    def _split_text_into_chunks(self, text: str, max_tokens: int) -> List[str]:
        """Split text into chunks of approximately equal size
        
        Args:
            text: Input text
            max_tokens: Maximum number of tokens per chunk
            
        Returns:
            List of text chunks
        """
        if not text:
            return []
            
        # Split text into paragraphs
        paragraphs = text.split("\n\n")
        chunks = []
        current_chunk = []
        current_length = 0
        
        for paragraph in paragraphs:
            # Split paragraph into sentences
            sentences = paragraph.split(". ")
            
            for sentence in sentences:
                if not sentence.strip():
                    continue
                    
                # Add period back to sentence
                sentence = sentence + ". "
                
                # Estimate token length (rough approximation)
                sentence_length = len(sentence.split())
                
                # If adding this sentence would exceed chunk size, start new chunk
                if current_length + sentence_length > max_tokens:
                    if current_chunk:
                        chunks.append("".join(current_chunk))
                        current_chunk = []
                        current_length = 0
                
                current_chunk.append(sentence)
                current_length += sentence_length
            
            # Add paragraph break if we have a chunk
            if current_chunk:
                current_chunk.append("\n\n")
                current_length += 2  # For the paragraph break
        
        # Add remaining chunk if any
        if current_chunk:
            chunks.append("".join(current_chunk))
            
        return chunks

# Initialize OpenAI API client
openai_api = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
