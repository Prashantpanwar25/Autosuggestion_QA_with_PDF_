import numpy as np
from typing import List, Dict, Any
from sklearn.metrics.pairwise import cosine_similarity
import logging
import openai
import tiktoken

class VectorStore:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.vectors = []
        self.text_chunks = []
        self.suggestion_threshold = 0.3  # Minimum similarity for suggestions
        self.response_threshold = 0.5  # Higher threshold for responses
        self.max_suggestion_length = 200  # Increased length for better context
        self.max_suggestions = 5  # Increased number of suggestions
        self.min_suggestion_length = 30  # Minimum length for suggestions
        self.encoding = tiktoken.get_encoding("cl100k_base")  # GPT-3.5 encoding
        self.max_context_tokens = 8000  # Maximum context tokens for GPT-3.5
        self.token_limit_buffer = 100  # Buffer to account for tokenization differences
        self.question_patterns = [
            "How does",
            "What is",
            "What are the",
            "Which",
            "Why",
            "When",
            "Can",
            "Could",
            "Would",
            "Should"
        ]

    def _count_tokens(self, text: str) -> int:
        """Count tokens in text using the same encoding as GPT-3.5"""
        return len(self.encoding.encode(text))

    def _is_question(self, text: str) -> bool:
        """Check if text is likely a question"""
        text = text.strip()
        if not text:
            return False
            
        # Check if it ends with a question mark
        if text[-1] == '?':
            return True
            
        # Check if it starts with common question patterns
        for pattern in self.question_patterns:
            if text.lower().startswith(pattern.lower()):
                return True
                
        return False

    def _convert_to_question(self, text: str) -> str:
        """Convert a statement into a question"""
        text = text.strip()
        
        # If it's already a question, return it
        if self._is_question(text):
            return text
            
        # Try to convert into a question
        if "is" in text.lower():
            return f"What is {text.lower().split('is')[1].strip()}?"
        elif "are" in text.lower():
            return f"What are {text.lower().split('are')[1].strip()}?"
        elif "does" in text.lower():
            return f"How does {text.lower().split('does')[1].strip()}?"
        elif "can" in text.lower():
            return f"Can {text.lower().split('can')[1].strip()}?"
        
        # If all else fails, use a generic question pattern
        return f"What is {text}?"

    async def add(self, text_chunks: List[str]) -> None:
        """Add text chunks to vector store"""
        try:
            # Generate embeddings for each chunk
            embeddings = await self._generate_embeddings(text_chunks)
            
            # Add to store
            self.vectors.extend(embeddings)
            self.text_chunks.extend(text_chunks)
            
            self.logger.info(f"Added {len(text_chunks)} chunks to vector store")
            
        except Exception as e:
            self.logger.error(f"Error adding to vector store: {str(e)}", exc_info=True)
            raise

    async def search(self, query: str, k: int = 3) -> List[str]:
        """Search for most relevant chunks"""
        try:
            # Generate query embedding
            query_embedding = await self._generate_embedding(query)
            
            # Calculate similarities
            similarities = cosine_similarity(
                np.array([query_embedding]),
                np.array(self.vectors)
            )[0]
            
            # Get indices above response threshold
            valid_indices = np.where(similarities > self.response_threshold)[0]
            
            if len(valid_indices) == 0:
                # If no results above threshold, take top k
                valid_indices = np.argsort(similarities)[-k:][::-1]
            else:
                # Sort by similarity and take top k
                sorted_indices = valid_indices[np.argsort(similarities[valid_indices])[::-1]]
                valid_indices = sorted_indices[:k]
            
            # Get corresponding chunks
            results = [self.text_chunks[i] for i in valid_indices]
            
            # Combine chunks for context
            context = "\n\n".join(results)
            
            # Ensure context doesn't exceed token limit with buffer
            while self._count_tokens(context) > self.max_context_tokens - self.token_limit_buffer:
                results.pop(-1)
                context = "\n\n".join(results)
            
            self.logger.info(f"Found {len(results)} relevant chunks")
            return results
            
        except Exception as e:
            self.logger.error(f"Error searching vector store: {str(e)}", exc_info=True)
            raise

    async def get_suggestions(self, partial_query: str, query_context: str = None) -> List[str]:
        """Get suggestions based on partial query and context"""
        try:
            if not partial_query.strip():
                return []
                
            # Generate query embedding
            query_embedding = await self._generate_embedding(partial_query)
            
            # Calculate similarities
            similarities = cosine_similarity(
                np.array([query_embedding]),
                np.array(self.vectors)
            )[0]
            
            # Get indices above suggestion threshold
            valid_indices = np.where(similarities > self.suggestion_threshold)[0]
            
            if len(valid_indices) == 0:
                self.logger.info(f"No suggestions found (threshold={self.suggestion_threshold})")
                return []
                
            # Sort by similarity and get top results
            sorted_indices = valid_indices[np.argsort(similarities[valid_indices])[::-1]]
            
            # Get corresponding chunks
            results = []
            seen = set()
            
            for i in sorted_indices[:15]:  # Consider top 15 candidates
                chunk = self.text_chunks[i]
                
                # Skip if it's an exact match or too similar
                if (partial_query.lower() in chunk.lower() or 
                    similarities[i] > 0.9):
                    continue
                    
                # Clean up the suggestion
                suggestion = chunk.strip()
                
                # Skip if too short or too long
                if len(suggestion) < self.min_suggestion_length:
                    continue
                    
                # Convert to question format if it's not already a question
                if not self._is_question(suggestion):
                    suggestion = self._convert_to_question(suggestion)
                
                # Truncate long suggestions while preserving context
                if len(suggestion) > self.max_suggestion_length:
                    # Try to find a good place to truncate
                    last_period = suggestion.rfind(".", 0, self.max_suggestion_length)
                    if last_period != -1:
                        suggestion = suggestion[:last_period + 1] + "..."
                    else:
                        suggestion = suggestion[:self.max_suggestion_length] + "..."
                
                # Skip duplicates
                if suggestion.lower() not in seen:
                    seen.add(suggestion.lower())
                    
                    # Add context if available
                    if query_context and len(results) < 3:
                        # Generate context-aware suggestion
                        context_suggestion = await self._generate_context_aware_suggestion(
                            suggestion, query_context, similarities[i]
                        )
                        if context_suggestion:
                            results.append(context_suggestion)
                    else:
                        results.append(suggestion)
                    
                if len(results) >= self.max_suggestions:  # Limit to max suggestions
                    break
            
            # If we have too few suggestions, try with a lower threshold
            if len(results) < 3:
                self.logger.info(f"Too few suggestions ({len(results)}), trying with lower threshold")
                lower_threshold = max(0.1, self.suggestion_threshold - 0.1)
                valid_indices = np.where(similarities > lower_threshold)[0]
                sorted_indices = valid_indices[np.argsort(similarities[valid_indices])[::-1]]
                
                for i in sorted_indices[:15]:  # Consider top 15 candidates
                    if len(results) >= self.max_suggestions:
                        break
                        
                    chunk = self.text_chunks[i]
                    suggestion = chunk.strip()
                    
                    if len(suggestion) < self.min_suggestion_length:
                        continue
                        
                    if suggestion.lower() not in seen:
                        seen.add(suggestion.lower())
                        
                        # Convert to question format if it's not already a question
                        if not self._is_question(suggestion):
                            suggestion = self._convert_to_question(suggestion)
                            
                        results.append(suggestion)
            
            if results:
                self.logger.info(f"Generated {len(results)} suggestions")
            else:
                self.logger.info("No valid suggestions found")
            
            return results
            
        except Exception as e:
            self.logger.error(f"Error getting suggestions: {str(e)}", exc_info=True)
            raise

    async def _generate_context_aware_suggestion(self, suggestion: str, context: str, similarity: float) -> str:
        """Generate a context-aware suggestion"""
        try:
            # Create prompt
            prompt = f"""
            Original suggestion: {suggestion}
            
            Context: {context}
            
            Generate a more relevant question based on the context and original suggestion.
            The question should be specific, clear, and relevant to the topic.
            Use one of these question patterns:
            - How does
            - What is
            - What are the
            - Which
            - Why
            - When
            - Can
            - Could
            - Would
            - Should
            
            Return only the question.
            """
            
            # Generate the improved suggestion
            response = await openai.ChatCompletion.acreate(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a helpful assistant that generates relevant questions."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=100
            )
            
            improved_suggestion = response.choices[0].message.content
            return improved_suggestion
        except Exception as e:
            self.logger.error(f"Error generating context-aware suggestion: {str(e)}", exc_info=True)
            return suggestion  # Return original suggestion if context-aware generation fails

    async def _generate_embedding(self, text: str) -> np.ndarray:
        """Generate embedding for single text"""
        try:
            # Generate embedding
            response = await openai.Embedding.acreate(
                input=text,
                model="text-embedding-3-small"
            )
            embedding = response.data[0].embedding
            return np.array(embedding)
            
        except Exception as e:
            self.logger.error(f"Error generating embedding: {str(e)}", exc_info=True)
            raise

    async def _generate_embeddings(self, texts: List[str]) -> List[np.ndarray]:
        """Generate embeddings for multiple texts"""
        try:
            # Generate embeddings in batches
            batch_size = 10
            embeddings = []
            
            for i in range(0, len(texts), batch_size):
                batch = texts[i:i + batch_size]
                
                # Generate embeddings for batch
                response = await openai.Embedding.acreate(
                    input=batch,
                    model="text-embedding-3-small"
                )
                
                # Extract embeddings
                batch_embeddings = [np.array(e.embedding) for e in response.data]
                embeddings.extend(batch_embeddings)
            
            return embeddings
            
        except Exception as e:
            self.logger.error(f"Error generating embeddings: {str(e)}", exc_info=True)
            raise

    def clear(self) -> None:
        """Clear all vectors and text chunks"""
        self.vectors = []
        self.text_chunks = []
        self.logger.info("Cleared vector store")
