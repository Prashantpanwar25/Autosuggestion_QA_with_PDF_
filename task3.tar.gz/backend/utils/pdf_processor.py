import fitz  # PyMuPDF
from typing import List, Dict, Any
import logging
import re
import tiktoken

class PDFProcessor:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.encoding = tiktoken.get_encoding("cl100k_base")  # GPT-3.5 encoding
        self.max_chunk_tokens = 1500  # Maximum tokens per chunk
        self.min_chunk_tokens = 200   # Minimum tokens per chunk
        self.overlap_tokens = 100     # Overlap between chunks
        
    def _count_tokens(self, text: str) -> int:
        """Count tokens in text using the same encoding as GPT-3.5"""
        return len(self.encoding.encode(text))

    def _split_text(self, text: str) -> List[str]:
        """Split text into chunks with token limits"""
        try:
            # Clean text
            text = text.strip()
            text = re.sub(r'\s+', ' ', text)
            
            # Split by paragraphs
            paragraphs = text.split('\n\n')
            
            chunks = []
            current_chunk = []
            current_tokens = 0
            
            for paragraph in paragraphs:
                para_tokens = self._count_tokens(paragraph)
                
                # If paragraph is too large, split it
                if para_tokens > self.max_chunk_tokens:
                    words = paragraph.split()
                    current_word = []
                    current_word_tokens = 0
                    
                    for word in words:
                        word_tokens = self._count_tokens(word)
                        
                        if current_word_tokens + word_tokens > self.max_chunk_tokens:
                            if current_word:
                                chunks.append(' '.join(current_word))
                            current_word = [word]
                            current_word_tokens = word_tokens
                        else:
                            current_word.append(word)
                            current_word_tokens += word_tokens
                    
                    if current_word:
                        chunks.append(' '.join(current_word))
                else:
                    # Add paragraph to current chunk
                    if current_tokens + para_tokens > self.max_chunk_tokens:
                        if current_chunk:
                            chunks.append(' '.join(current_chunk))
                        current_chunk = [paragraph]
                        current_tokens = para_tokens
                    else:
                        current_chunk.append(paragraph)
                        current_tokens += para_tokens
            
            # Add last chunk
            if current_chunk:
                chunks.append(' '.join(current_chunk))
            
            # Add overlap between chunks
            final_chunks = []
            for i in range(len(chunks)):
                chunk = chunks[i]
                if i > 0:
                    # Add overlap with previous chunk
                    prev_chunk = chunks[i-1]
                    overlap = prev_chunk[-self.overlap_tokens:]
                    chunk = overlap + chunk
                
                # Ensure minimum chunk size
                if self._count_tokens(chunk) >= self.min_chunk_tokens:
                    final_chunks.append(chunk)
            
            self.logger.info(f"Split text into {len(final_chunks)} chunks")
            return final_chunks
            
        except Exception as e:
            self.logger.error(f"Error splitting text: {str(e)}", exc_info=True)
            raise

    async def process_pdf(self, file_name: str, file_bytes: bytes) -> List[str]:
        """Process PDF file and return text chunks"""
        try:
            self.logger.info(f"Processing PDF: {file_name}")
            
            # Open PDF
            pdf = fitz.open("pdf", file_bytes)
            
            # Extract text from each page
            text = ""
            for page_num in range(len(pdf)):
                page = pdf[page_num]
                text += page.get_text() + "\n\n"
            
            # Close PDF
            pdf.close()
            
            # Clean text
            text = self.clean_text(text)
            
            # Split text into chunks
            chunks = self._split_text(text)
            
            # Log statistics
            total_tokens = sum(self._count_tokens(chunk) for chunk in chunks)
            self.logger.info(f"Processed {file_name}: {len(chunks)} chunks, total tokens: {total_tokens}")
            
            return chunks
            
        except Exception as e:
            self.logger.error(f"Error processing PDF: {str(e)}", exc_info=True)
            raise

    def clean_text(self, text: str) -> str:
        """Clean extracted text"""
        try:
            # Remove extra whitespace
            text = re.sub(r'\s+', ' ', text)
            
            # Remove page numbers
            text = re.sub(r'\b\d{1,3}\b', '', text)
            
            # Remove common header/footer patterns
            text = re.sub(r'\bPage\s+\d+\b', '', text)
            text = re.sub(r'\bConfidential\b', '', text)
            
            # Remove multiple newlines
            text = re.sub(r'\n\s*\n', '\n\n', text)
            
            return text.strip()
            
        except Exception as e:
            self.logger.error(f"Error cleaning text: {str(e)}", exc_info=True)
            raise
