from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import logging
import asyncio
from typing import List, Dict, Any
from pydantic import BaseModel
from backend.utils.pdf_processor import PDFProcessor
from backend.utils.vector_store import VectorStore
import openai
import os
from dotenv import load_dotenv

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Initialize app
app = FastAPI()
app.pdf_uploaded = False

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize PDF processor and vector store
pdf_processor = PDFProcessor()  # Initialize without chunk_size parameter
vector_store = VectorStore()

# Initialize OpenAI API using environment variable
openai.api_key = os.getenv("OPENAI_API_KEY")

# Request models
class QueryRequest(BaseModel):
    question: str

class SuggestRequest(BaseModel):
    partial_query: str
    query_context: str = None

@app.post("/upload")
async def upload_pdf(file: UploadFile = File(...)):
    """Upload and process PDF file"""
    try:
        logger.info(f"Uploading file: {file.filename}")
        
        # Check if file is PDF
        if not file.filename.endswith('.pdf'):
            raise HTTPException(status_code=400, detail="File must be a PDF")

        # Read file in chunks to reduce memory usage
        chunks = []
        while content := await file.read(1024 * 1024):  # Read 1MB chunks
            chunks.append(content)

        # Process PDF
        pdf_bytes = b''.join(chunks)
        text_chunks = await pdf_processor.process_pdf(file.filename, pdf_bytes)
        
        if not text_chunks:
            raise HTTPException(status_code=400, detail="No text extracted from PDF")
            
        # Add to vector store
        await vector_store.add(text_chunks)
        
        # Store PDF uploaded state
        app.pdf_uploaded = True
        
        logger.info(f"Successfully processed {len(text_chunks)} chunks from {file.filename}")
        return {"status": "success", "message": f"Successfully processed {len(text_chunks)} chunks"}
        
    except Exception as e:
        logger.error(f"Error uploading PDF: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/query")
async def query(request: QueryRequest):
    """Get response for a query"""
    try:
        logger.info(f"Query received: {request.question}")
        
        if not request.question.strip():
            raise HTTPException(status_code=400, detail="Question cannot be empty")
            
        if not app.pdf_uploaded:
            raise HTTPException(status_code=400, detail="No PDF uploaded")
            
        # Search for relevant chunks
        relevant_chunks = await vector_store.search(request.question, k=3)
        
        if not relevant_chunks:
            logger.warning("No relevant chunks found")
            return {"status": "success", "answer": "I couldn't find any relevant information in the document."}
            
        # Combine chunks for context
        context = "\n\n".join(relevant_chunks)
        
        # Generate response using OpenAI
        try:
            response = await openai.ChatCompletion.acreate(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": f"Here is the context from the document:\n\n{context}\n\nQuestion: {request.question}"}
                ]
            )
            
            answer = response.choices[0].message.content
            logger.info("Successfully generated response")
            return {"status": "success", "answer": answer, "context": context}
            
        except Exception as e:
            logger.error(f"Error generating response: {str(e)}", exc_info=True)
            raise HTTPException(status_code=500, detail="Error generating response")
            
    except Exception as e:
        logger.error(f"Error processing query: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/suggest")
async def suggest(request: SuggestRequest):
    """Get suggestions based on partial query and context"""
    try:
        logger.info(f"Getting suggestions for: {request.partial_query}")
        
        if not request.partial_query.strip():
            raise HTTPException(status_code=400, detail="Query cannot be empty")
            
        if not app.pdf_uploaded:
            raise HTTPException(status_code=400, detail="No PDF uploaded")
            
        # Get suggestions with context
        suggestions = await vector_store.get_suggestions(
            request.partial_query,
            request.query_context
        )
        
        logger.info(f"Generated {len(suggestions)} suggestions")
        return {"status": "success", "suggestions": suggestions}
        
    except Exception as e:
        logger.error(f"Error getting suggestions: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=6565, reload=True)
