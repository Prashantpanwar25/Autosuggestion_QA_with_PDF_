import streamlit as st
from streamlit_chat import message
import asyncio
import logging
from frontend.utils.api_client import APIClient
from frontend.utils.constants import UI_TEXT, SESSION_KEYS
import hashlib

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize API client
api_client = APIClient("http://localhost:6565")

# Initialize session state
for key, value in SESSION_KEYS.items():
    if value not in st.session_state:
        st.session_state[value] = [] if key in ["messages", "suggestions"] else False

async def upload_pdf_async(file_name: str, file_bytes: bytes):
    """Async function to upload PDF to backend"""
    try:
        response = await api_client.upload_pdf(file_name, file_bytes)
        return response
    except Exception as e:
        logger.error(f"Error uploading PDF: {str(e)}", exc_info=True)
        raise

def process_query(query: str):
    """Process a query and update chat"""
    if not query or not query.strip():
        return
        
    if not st.session_state.pdf_uploaded:
        st.warning(UI_TEXT["upload"]["disabled_message"])
        return
        
    if query == st.session_state.last_query:
        return
        
    st.session_state.last_query = query
    st.session_state.suggestions = []
    
    # Add user message
    st.session_state.messages.append({"role": "user", "content": query})
    
    # Get response from API
    with st.spinner(UI_TEXT["loaders"]["query"]):
        try:
            st.session_state.processing_query = True
            
            # Get response
            response = api_client.run(api_client.query({"question": query}))
            
            if response["status"] == "success":
                st.session_state.messages.append({"role": "assistant", "content": response["answer"]})
                
                # Get suggestions with context
                with st.spinner(UI_TEXT["loaders"]["suggestions"]):
                    suggestions = api_client.run(api_client.get_suggestions({
                        "partial_query": query,
                        "query_context": response.get("context", "")
                    }))
                    
                    if suggestions["status"] == "success" and suggestions["suggestions"]:
                        # Clean and deduplicate suggestions
                        cleaned_suggestions = []
                        seen = set()
                        
                        for s in suggestions["suggestions"]:
                            # Remove duplicates and exact matches
                            if s.lower() not in seen and s.lower() != query.lower():
                                seen.add(s.lower())
                                cleaned_suggestions.append(s)
                        
                        st.session_state.suggestions = cleaned_suggestions
                        st.session_state.current_suggestions = cleaned_suggestions
                        st.success(UI_TEXT["notifications"]["suggestions_found"].format(count=len(cleaned_suggestions)))
                
                st.success(UI_TEXT["notifications"]["query_success"])
                st.rerun()
            else:
                error_msg = f"Error getting response: {response.get('error', 'Unknown error')}"
                logger.error(error_msg)
                st.error(error_msg)
                st.rerun()
        except Exception as e:
            logger.error(f"Error processing query: {str(e)}", exc_info=True)
            st.error(f"Error processing query: {str(e)}")
            st.rerun()
        finally:
            st.session_state.processing_query = False

# Sidebar with file upload
with st.sidebar:
    st.header(UI_TEXT["upload"]["title"])
    st.markdown(UI_TEXT["upload"]["description"])
    
    uploaded_file = st.file_uploader(
        "Choose a PDF file",
        type="pdf",
        key="pdf_uploader",
        help="Upload a PDF file to get started"
    )
    
    if uploaded_file and not st.session_state.pdf_uploaded:
        try:
            st.session_state.uploading = True
            st.info(UI_TEXT["loaders"]["upload"])
            
            # Convert file to bytes
            file_bytes = uploaded_file.read()
            
            # Upload file asynchronously
            result = api_client.run(upload_pdf_async(uploaded_file.name, file_bytes))
            
            if result:
                st.session_state.upload_notification = st.success(UI_TEXT["notifications"]["upload_success"])
                st.session_state.messages = []
                st.session_state.pdf_uploaded = True
                st.rerun()
            
        except Exception as e:
            logger.error(f"Error uploading document: {str(e)}", exc_info=True)
            st.error(f"Error uploading document: {str(e)}")
            st.rerun()
        finally:
            st.session_state.uploading = False

    if st.button(UI_TEXT["upload"]["button"], use_container_width=True):
        st.session_state.messages = []
        st.session_state.pdf_uploaded = False
        st.session_state.last_query = None
        st.session_state.suggestions = []
        st.session_state.upload_notification = None
        st.session_state.current_suggestions = []
        st.rerun()

# Main chat interface
st.title(UI_TEXT["chat"]["title"])

# Display upload notification if present
if st.session_state.upload_notification:
    st.success(UI_TEXT["notifications"]["upload_success"])

# Display chat messages
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# Display current suggestions if present
if st.session_state.current_suggestions:
    with st.expander("💡 Related Questions", expanded=True):
        for i, suggestion in enumerate(st.session_state.current_suggestions):
            # Generate unique key for each button
            button_key = f"suggestion_{i}_{hashlib.md5(suggestion.encode()).hexdigest()[:8]}"
            
            # Split suggestion into title and content
            parts = suggestion.split(".", 1)
            title = parts[0] + "." if len(parts) > 0 else suggestion
            content = parts[1] if len(parts) > 1 else ""
            
            # Create a card-like layout for each suggestion
            with st.container():
                st.markdown(f"**{title}**")
                if content:
                    st.markdown(content)
                
                if st.button("Ask", key=f"button_{button_key}", use_container_width=True):
                    st.session_state.messages.pop()  # Remove the original query
                    process_query(suggestion)

# User input
if prompt := st.chat_input(UI_TEXT["chat"]["input_placeholder"], disabled=not st.session_state.pdf_uploaded):
    process_query(prompt)
