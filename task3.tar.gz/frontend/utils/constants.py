API_URL = "http://localhost:6565"

# Session state keys
SESSION_KEYS = {
    "messages": "messages",
    "pdf_uploaded": "pdf_uploaded",
    "suggestions": "suggestions",
    "last_suggestion_time": "last_suggestion_time",
    "last_query": "last_query",
    "uploading": "uploading",
    "processing_query": "processing_query",
    "upload_notification": "upload_notification",
    "current_suggestions": "current_suggestions"
}

# UI text
UI_TEXT = {
    "upload": {
        "title": "📚 Document Upload",
        "description": "Upload your PDF document to start the conversation.",
        "button": "Start New Chat"
    },
    "chat": {
        "title": "PDF Chatbot 📚",
        "input_placeholder": "What would you like to know?",
        "disabled_message": "📄 Please upload a PDF document first!"
    },
    "notifications": {
        "upload_success": "Document uploaded successfully!",
        "query_success": "Query processed successfully!",
        "suggestions_found": "Found {count} related questions!"
    },
    "loaders": {
        "upload": "Uploading PDF...",
        "query": "Processing your query...",
        "suggestions": "Generating suggestions..."
    }
}
