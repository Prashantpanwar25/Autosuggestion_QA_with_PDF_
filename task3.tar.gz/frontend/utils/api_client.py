import httpx
import logging
from typing import Dict, Any
import asyncio

class APIClient:
    def __init__(self, base_url: str):
        self.base_url = base_url
        self.logger = logging.getLogger(__name__)
        self._loop = None
        
        # Set longer timeouts for large file uploads
        self.client = httpx.AsyncClient(
            timeout=httpx.Timeout(
                connect=30.0,  # Connection timeout
                read=600.0,    # Read timeout (10 minutes)
                write=30.0,    # Write timeout
                pool=30.0      # Pool timeout
            )
        )

    def _get_event_loop(self):
        """Get or create event loop"""
        try:
            loop = asyncio.get_event_loop()
            if loop.is_closed():
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
            return loop
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            return loop

    async def upload_pdf(self, file_name: str, file_bytes: bytes) -> Dict[str, Any]:
        """Upload PDF file to backend"""
        try:
            files = {"file": (file_name, file_bytes, "application/pdf")}
            response = await self.client.post(f"{self.base_url}/upload", files=files)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            self.logger.error(f"Error uploading PDF: {str(e)}", exc_info=True)
            raise

    async def query(self, request: Dict[str, str]) -> Dict[str, Any]:
        """Send query to backend"""
        try:
            response = await self.client.post(f"{self.base_url}/query", json=request)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            self.logger.error(f"Error querying: {str(e)}", exc_info=True)
            raise

    async def get_suggestions(self, request: Dict[str, str]) -> Dict[str, Any]:
        """Get suggestions from backend"""
        try:
            response = await self.client.post(f"{self.base_url}/suggest", json=request)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            self.logger.error(f"Error getting suggestions: {str(e)}", exc_info=True)
            raise

    async def close(self):
        """Close the client connection"""
        try:
            await self.client.aclose()
        except Exception as e:
            self.logger.error(f"Error closing client: {str(e)}", exc_info=True)

    def run(self, coro):
        """Run a coroutine"""
        loop = self._get_event_loop()
        return loop.run_until_complete(coro)

# Initialize API client
api_client = APIClient("http://localhost:6565")
